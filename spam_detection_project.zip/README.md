# AI Spam Message Detector

This project is an AI-powered Spam Message Detector built using Python.

## Project Structure
- `dataset/`: Contains raw and processed data.
- `model/`: Saved trained ML/DL models.
- `src/`: Source code for utility scripts, feature extraction, etc.
- `train.py`: Script to train the spam detection model.
- `app.py`: Web application or interface to test the model.
- `requirements.txt`: Python package dependencies.
- `README.md`: Project documentation.
